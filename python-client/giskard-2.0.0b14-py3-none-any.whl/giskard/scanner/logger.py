import logging


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
