class ConnectionLost(Exception):
    pass
